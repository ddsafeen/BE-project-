"use client"

import type React from "react"

import { useChat } from "ai/react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Send, Bot, User, AlertCircle } from "lucide-react"
import { useEffect, useRef } from "react"

interface AIChatInterfaceProps {
  userName: string
}

export default function AIChatInterface({ userName }: AIChatInterfaceProps) {
  const { messages, input, handleInputChange, handleSubmit, isLoading, error } = useChat({
    api: "/api/chat",
  })

  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  return (
    <div className="max-w-4xl mx-auto">
      <Card className="shadow-lg">
        <CardHeader className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
          <CardTitle className="flex items-center gap-2">
            <Bot className="w-6 h-6" />
            AI Health Assistant
          </CardTitle>
          <CardDescription className="text-blue-50">
            Ask me about symptoms, general health advice, or medical information
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          {/* Disclaimer */}
          <div className="p-4 bg-yellow-50 border-b border-yellow-200">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-yellow-800">
                <strong>Important:</strong> This AI assistant provides general health information only. It is not a
                substitute for professional medical advice, diagnosis, or treatment. Always consult with a qualified
                healthcare provider for medical concerns.
              </div>
            </div>
          </div>

          {/* Messages */}
          <div className="h-[500px] overflow-y-auto p-4 space-y-4 bg-gray-50">
            {messages.length === 0 && (
              <div className="text-center py-12">
                <Bot className="w-16 h-16 mx-auto text-blue-500 mb-4" />
                <h3 className="text-lg font-semibold mb-2">Welcome, {userName}!</h3>
                <p className="text-muted-foreground mb-4">
                  I&apos;m your AI health assistant. How can I help you today?
                </p>
                <div className="grid md:grid-cols-2 gap-2 max-w-2xl mx-auto">
                  <Button
                    variant="outline"
                    className="text-left justify-start h-auto py-3 bg-transparent"
                    onClick={() => {
                      const event = {
                        preventDefault: () => {},
                      } as React.FormEvent<HTMLFormElement>
                      handleInputChange({
                        target: { value: "What are common symptoms of the flu?" },
                      } as React.ChangeEvent<HTMLInputElement>)
                      setTimeout(() => handleSubmit(event), 100)
                    }}
                  >
                    <span className="text-sm">What are common symptoms of the flu?</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="text-left justify-start h-auto py-3 bg-transparent"
                    onClick={() => {
                      const event = {
                        preventDefault: () => {},
                      } as React.FormEvent<HTMLFormElement>
                      handleInputChange({
                        target: { value: "How can I improve my sleep quality?" },
                      } as React.ChangeEvent<HTMLInputElement>)
                      setTimeout(() => handleSubmit(event), 100)
                    }}
                  >
                    <span className="text-sm">How can I improve my sleep quality?</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="text-left justify-start h-auto py-3 bg-transparent"
                    onClick={() => {
                      const event = {
                        preventDefault: () => {},
                      } as React.FormEvent<HTMLFormElement>
                      handleInputChange({
                        target: { value: "What should I do for a headache?" },
                      } as React.ChangeEvent<HTMLInputElement>)
                      setTimeout(() => handleSubmit(event), 100)
                    }}
                  >
                    <span className="text-sm">What should I do for a headache?</span>
                  </Button>
                  <Button
                    variant="outline"
                    className="text-left justify-start h-auto py-3 bg-transparent"
                    onClick={() => {
                      const event = {
                        preventDefault: () => {},
                      } as React.FormEvent<HTMLFormElement>
                      handleInputChange({
                        target: { value: "Tips for maintaining a healthy diet?" },
                      } as React.ChangeEvent<HTMLInputElement>)
                      setTimeout(() => handleSubmit(event), 100)
                    }}
                  >
                    <span className="text-sm">Tips for maintaining a healthy diet?</span>
                  </Button>
                </div>
              </div>
            )}

            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.role === "assistant" && (
                  <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                )}
                <div
                  className={`max-w-[80%] rounded-lg p-4 ${
                    message.role === "user" ? "bg-blue-600 text-white" : "bg-white border border-gray-200 text-gray-900"
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                </div>
                {message.role === "user" && (
                  <div className="w-8 h-8 rounded-full bg-gray-600 flex items-center justify-center flex-shrink-0">
                    <User className="w-5 h-5 text-white" />
                  </div>
                )}
              </div>
            ))}

            {isLoading && (
              <div className="flex gap-3 justify-start">
                <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center flex-shrink-0">
                  <Bot className="w-5 h-5 text-white" />
                </div>
                <div className="bg-white border border-gray-200 rounded-lg p-4">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100" />
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200" />
                  </div>
                </div>
              </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <p className="text-sm text-red-800">Error: {error.message}</p>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-4 bg-white border-t">
            <form onSubmit={handleSubmit} className="flex gap-2">
              <Input
                value={input}
                onChange={handleInputChange}
                placeholder="Ask about your health concerns..."
                disabled={isLoading}
                className="flex-1"
              />
              <Button type="submit" disabled={isLoading || !input.trim()}>
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
