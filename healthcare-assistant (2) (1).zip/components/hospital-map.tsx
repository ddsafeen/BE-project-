"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { MapPin, Phone, Search } from "lucide-react"

interface Hospital {
  id: string
  name: string
  address: string
  city: string
  state: string
  phone: string
  latitude: number
  longitude: number
}

interface HospitalMapProps {
  hospitals: Hospital[]
}

export default function HospitalMap({ hospitals }: HospitalMapProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null)

  const filteredHospitals = hospitals.filter(
    (hospital) =>
      hospital.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      hospital.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
      hospital.address.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      {/* Hospital List */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
          <Input
            placeholder="Search hospitals by name, city, or address..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="space-y-3 max-h-[600px] overflow-y-auto">
          {filteredHospitals.length > 0 ? (
            filteredHospitals.map((hospital) => (
              <Card
                key={hospital.id}
                className={`cursor-pointer transition-all hover:shadow-md ${
                  selectedHospital?.id === hospital.id ? "border-blue-500 border-2" : ""
                }`}
                onClick={() => setSelectedHospital(hospital)}
              >
                <CardHeader className="pb-3">
                  <CardTitle className="text-lg">{hospital.name}</CardTitle>
                  <CardDescription className="flex items-start gap-2">
                    <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>
                      {hospital.address}, {hospital.city}, {hospital.state}
                    </span>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Phone className="w-4 h-4" />
                    <span>{hospital.phone}</span>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <Card>
              <CardContent className="text-center py-8">
                <p className="text-muted-foreground">No hospitals found matching your search</p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Map View */}
      <div className="lg:sticky lg:top-4 h-fit">
        <Card>
          <CardHeader>
            <CardTitle>Hospital Locations</CardTitle>
            <CardDescription>
              {selectedHospital ? `Showing: ${selectedHospital.name}` : "Select a hospital to view details"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="relative w-full h-[500px] bg-gradient-to-br from-blue-100 to-cyan-100 rounded-lg overflow-hidden">
              {/* Map placeholder with visual representation */}
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center space-y-4 p-6">
                  <div className="w-16 h-16 mx-auto bg-blue-500 rounded-full flex items-center justify-center">
                    <MapPin className="w-8 h-8 text-white" />
                  </div>
                  {selectedHospital ? (
                    <div className="bg-white rounded-lg p-6 shadow-lg max-w-sm">
                      <h3 className="font-bold text-lg mb-2">{selectedHospital.name}</h3>
                      <div className="space-y-2 text-sm text-left">
                        <div className="flex items-start gap-2">
                          <MapPin className="w-4 h-4 mt-0.5 text-blue-600 flex-shrink-0" />
                          <p className="text-muted-foreground">
                            {selectedHospital.address}
                            <br />
                            {selectedHospital.city}, {selectedHospital.state}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Phone className="w-4 h-4 text-blue-600" />
                          <p className="text-muted-foreground">{selectedHospital.phone}</p>
                        </div>
                        <div className="pt-2 border-t">
                          <p className="text-xs text-muted-foreground">
                            Coordinates: {selectedHospital.latitude.toFixed(4)}, {selectedHospital.longitude.toFixed(4)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-white rounded-lg p-6 shadow-lg">
                      <p className="text-muted-foreground">
                        Click on a hospital from the list to view its location and details
                      </p>
                    </div>
                  )}
                </div>
              </div>

              {/* Decorative map grid */}
              <div className="absolute inset-0 opacity-10">
                <div className="grid grid-cols-8 grid-rows-8 h-full w-full">
                  {Array.from({ length: 64 }).map((_, i) => (
                    <div key={i} className="border border-blue-300" />
                  ))}
                </div>
              </div>

              {/* Hospital markers visualization */}
              {filteredHospitals.slice(0, 5).map((hospital, index) => (
                <div
                  key={hospital.id}
                  className={`absolute w-8 h-8 rounded-full flex items-center justify-center transition-all ${
                    selectedHospital?.id === hospital.id ? "bg-blue-600 scale-125 z-10" : "bg-blue-400 hover:scale-110"
                  }`}
                  style={{
                    left: `${20 + index * 15}%`,
                    top: `${30 + (index % 3) * 20}%`,
                  }}
                  onClick={() => setSelectedHospital(hospital)}
                >
                  <MapPin className="w-5 h-5 text-white" />
                </div>
              ))}
            </div>

            <div className="mt-4 p-4 bg-blue-50 rounded-lg">
              <p className="text-sm text-muted-foreground">
                <strong>Note:</strong> This is a visual representation of hospital locations. For precise navigation,
                please use the address provided with your preferred maps application.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
