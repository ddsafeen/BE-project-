import { createClient } from "@supabase/supabase-js"
import { NextResponse, type NextRequest } from "next/server"

export async function updateSession(request: NextRequest) {
  const supabaseResponse = NextResponse.next({
    request,
  })

  const authToken = request.cookies.get("sb-access-token")?.value
  const refreshToken = request.cookies.get("sb-refresh-token")?.value

  const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    auth: {
      persistSession: false,
    },
  })

  if (authToken && refreshToken) {
    const { data, error } = await supabase.auth.setSession({
      access_token: authToken,
      refresh_token: refreshToken,
    })

    if (!error && data.session) {
      // Refresh the session tokens
      const { session } = data
      supabaseResponse.cookies.set("sb-access-token", session.access_token, {
        path: "/",
        secure: true,
        httpOnly: true,
        sameSite: "lax",
      })
      supabaseResponse.cookies.set("sb-refresh-token", session.refresh_token, {
        path: "/",
        secure: true,
        httpOnly: true,
        sameSite: "lax",
      })
    }
  }

  const {
    data: { user },
  } = await supabase.auth.getUser(authToken)

  // Redirect to login if not authenticated and not on auth pages
  if (!user && !request.nextUrl.pathname.startsWith("/auth") && request.nextUrl.pathname !== "/") {
    const url = request.nextUrl.clone()
    url.pathname = "/auth/login"
    return NextResponse.redirect(url)
  }

  return supabaseResponse
}
