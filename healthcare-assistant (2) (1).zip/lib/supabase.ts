import { createClient as createSupabaseClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export function createClient() {
  return createSupabaseClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
      storage: typeof window !== "undefined" ? window.localStorage : undefined,
    },
  })
}

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          full_name: string
          role: "patient" | "doctor"
          created_at: string
        }
      }
      doctors: {
        Row: {
          id: string
          user_id: string
          specialization: string
          license_number: string
          hospital_id: string
          available: boolean
          created_at: string
        }
      }
      patients: {
        Row: {
          id: string
          user_id: string
          date_of_birth: string
          blood_group: string
          medical_history: string
          created_at: string
        }
      }
      hospitals: {
        Row: {
          id: string
          name: string
          address: string
          city: string
          phone: string
          latitude: number
          longitude: number
          created_at: string
        }
      }
      appointments: {
        Row: {
          id: string
          patient_id: string
          doctor_id: string
          hospital_id: string
          appointment_date: string
          appointment_time: string
          status: "pending" | "confirmed" | "completed" | "cancelled"
          reason: string
          created_at: string
        }
      }
      consultations: {
        Row: {
          id: string
          appointment_id: string
          diagnosis: string
          prescription: string
          notes: string
          created_at: string
        }
      }
      ai_chats: {
        Row: {
          id: string
          user_id: string
          messages: any
          created_at: string
        }
      }
    }
  }
}
