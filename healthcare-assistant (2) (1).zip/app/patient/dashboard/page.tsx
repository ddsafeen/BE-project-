import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Calendar, MessageSquare, MapPin, Activity, LogOut } from "lucide-react"

export default async function PatientDashboard() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (profile?.role !== "patient") {
    redirect("/doctor/dashboard")
  }

  // Get upcoming appointments
  const { data: appointments } = await supabase
    .from("appointments")
    .select(
      `
      *,
      doctor:doctor_id (
        id,
        profiles!inner (full_name)
      )
    `,
    )
    .eq("patient_id", user.id)
    .gte("appointment_date", new Date().toISOString().split("T")[0])
    .order("appointment_date", { ascending: true })
    .limit(3)

  const handleSignOut = async () => {
    "use server"
    const supabase = await createClient()
    await supabase.auth.signOut()
    redirect("/auth/login")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-blue-900">AI Healthcare Assistant</h1>
            <p className="text-sm text-muted-foreground">Patient Portal</p>
          </div>
          <form action={handleSignOut}>
            <Button variant="outline" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </form>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-blue-900 mb-2">Welcome back, {profile?.full_name || "Patient"}!</h2>
          <p className="text-muted-foreground">Manage your health and appointments from your dashboard</p>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Link href="/patient/appointments/book">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-300">
              <CardContent className="pt-6">
                <div className="rounded-full bg-blue-100 w-12 h-12 flex items-center justify-center mb-4">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-lg">Book Appointment</h3>
                <p className="text-sm text-muted-foreground">Schedule with a doctor</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/patient/consultations">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-cyan-300">
              <CardContent className="pt-6">
                <div className="rounded-full bg-cyan-100 w-12 h-12 flex items-center justify-center mb-4">
                  <Activity className="w-6 h-6 text-cyan-600" />
                </div>
                <h3 className="font-semibold text-lg">Consultations</h3>
                <p className="text-sm text-muted-foreground">View online sessions</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/patient/ai-chat">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-green-300">
              <CardContent className="pt-6">
                <div className="rounded-full bg-green-100 w-12 h-12 flex items-center justify-center mb-4">
                  <MessageSquare className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-lg">AI Assistant</h3>
                <p className="text-sm text-muted-foreground">Chat with AI doctor</p>
              </CardContent>
            </Card>
          </Link>

          <Link href="/patient/hospitals">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-purple-300">
              <CardContent className="pt-6">
                <div className="rounded-full bg-purple-100 w-12 h-12 flex items-center justify-center mb-4">
                  <MapPin className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold text-lg">Find Hospitals</h3>
                <p className="text-sm text-muted-foreground">Locate nearby facilities</p>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Upcoming Appointments */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Upcoming Appointments</CardTitle>
                <CardDescription>Your scheduled medical appointments</CardDescription>
              </div>
              <Button asChild variant="outline">
                <Link href="/patient/appointments">View All</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {appointments && appointments.length > 0 ? (
              <div className="space-y-4">
                {appointments.map((appointment: any) => (
                  <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-semibold">{appointment.doctor.profiles.full_name}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(appointment.appointment_date).toLocaleDateString()} at {appointment.appointment_time}
                      </p>
                      <p className="text-sm text-muted-foreground">{appointment.reason}</p>
                    </div>
                    <div className="text-right">
                      <span
                        className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                          appointment.status === "confirmed"
                            ? "bg-green-100 text-green-700"
                            : appointment.status === "scheduled"
                              ? "bg-blue-100 text-blue-700"
                              : "bg-gray-100 text-gray-700"
                        }`}
                      >
                        {appointment.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground mb-4">No upcoming appointments</p>
                <Button asChild>
                  <Link href="/patient/appointments/book">Book Your First Appointment</Link>
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
