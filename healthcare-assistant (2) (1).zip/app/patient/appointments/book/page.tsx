import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import BookAppointmentForm from "@/components/book-appointment-form"

export default async function BookAppointmentPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get all doctors
  const { data: doctors } = await supabase
    .from("doctors")
    .select(
      `
      *,
      profiles!inner (id, full_name, email)
    `,
    )
    .eq("available", true)

  // Get all hospitals
  const { data: hospitals } = await supabase.from("hospitals").select("*").order("name")

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Button asChild variant="ghost" size="sm" className="mb-2">
            <Link href="/patient/dashboard">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <h1 className="text-2xl font-bold text-blue-900">Book Appointment</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <BookAppointmentForm doctors={doctors || []} hospitals={hospitals || []} userId={user.id} />
      </div>
    </div>
  )
}
