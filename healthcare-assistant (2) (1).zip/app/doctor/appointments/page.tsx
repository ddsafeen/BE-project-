import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"
import UpdateAppointmentStatus from "@/components/update-appointment-status"

export default async function DoctorAppointmentsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get all appointments
  const { data: appointments } = await supabase
    .from("appointments")
    .select(
      `
      *,
      patient:patient_id (
        id,
        profiles!inner (full_name, phone, email)
      ),
      hospital:hospital_id (name, city)
    `,
    )
    .eq("doctor_id", user.id)
    .order("appointment_date", { ascending: false })

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Button asChild variant="ghost" size="sm" className="mb-2">
            <Link href="/doctor/dashboard">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <h1 className="text-2xl font-bold text-blue-900">Manage Appointments</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <h2 className="text-xl font-semibold mb-6">All Appointments</h2>

        {appointments && appointments.length > 0 ? (
          <div className="grid gap-4">
            {appointments.map((appointment: any) => (
              <Card key={appointment.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{appointment.patient.profiles.full_name}</CardTitle>
                      <CardDescription>
                        {new Date(appointment.appointment_date).toLocaleDateString("en-US", {
                          weekday: "long",
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}{" "}
                        at {appointment.appointment_time}
                      </CardDescription>
                    </div>
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                        appointment.status === "confirmed"
                          ? "bg-green-100 text-green-700"
                          : appointment.status === "scheduled"
                            ? "bg-blue-100 text-blue-700"
                            : appointment.status === "completed"
                              ? "bg-gray-100 text-gray-700"
                              : "bg-red-100 text-red-700"
                      }`}
                    >
                      {appointment.status}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium">Patient Contact</p>
                        <p className="text-sm text-muted-foreground">{appointment.patient.profiles.email}</p>
                        {appointment.patient.profiles.phone && (
                          <p className="text-sm text-muted-foreground">{appointment.patient.profiles.phone}</p>
                        )}
                      </div>
                      {appointment.hospital && (
                        <div>
                          <p className="text-sm font-medium">Location</p>
                          <p className="text-sm text-muted-foreground">
                            {appointment.hospital.name}, {appointment.hospital.city}
                          </p>
                        </div>
                      )}
                    </div>
                    <div>
                      <p className="text-sm font-medium">Reason for Visit</p>
                      <p className="text-sm text-muted-foreground">{appointment.reason || "General consultation"}</p>
                    </div>
                    {appointment.notes && (
                      <div>
                        <p className="text-sm font-medium">Notes</p>
                        <p className="text-sm text-muted-foreground">{appointment.notes}</p>
                      </div>
                    )}
                    <UpdateAppointmentStatus appointmentId={appointment.id} currentStatus={appointment.status} />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-muted-foreground">No appointments yet</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
