import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Calendar, Activity, Users, LogOut } from "lucide-react"

export default async function DoctorDashboard() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  if (profile?.role !== "doctor") {
    redirect("/patient/dashboard")
  }

  // Get doctor details
  const { data: doctorInfo } = await supabase.from("doctors").select("*").eq("id", user.id).single()

  // Get today's appointments
  const today = new Date().toISOString().split("T")[0]
  const { data: todayAppointments } = await supabase
    .from("appointments")
    .select(
      `
      *,
      patient:patient_id (
        id,
        profiles!inner (full_name, phone)
      )
    `,
    )
    .eq("doctor_id", user.id)
    .eq("appointment_date", today)
    .order("appointment_time", { ascending: true })

  // Get upcoming appointments count
  const { count: upcomingCount } = await supabase
    .from("appointments")
    .select("*", { count: "exact", head: true })
    .eq("doctor_id", user.id)
    .gte("appointment_date", today)

  // Get total patients count
  const { count: patientsCount } = await supabase
    .from("appointments")
    .select("patient_id", { count: "exact", head: true })
    .eq("doctor_id", user.id)

  const handleSignOut = async () => {
    "use server"
    const supabase = await createClient()
    await supabase.auth.signOut()
    redirect("/auth/login")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      {/* Header */}
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-blue-900">AI Healthcare Assistant</h1>
            <p className="text-sm text-muted-foreground">Doctor Portal</p>
          </div>
          <form action={handleSignOut}>
            <Button variant="outline" size="sm">
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </form>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-blue-900 mb-2">Welcome, Dr. {profile?.full_name || "Doctor"}!</h2>
          <p className="text-muted-foreground">
            {doctorInfo?.specialization && `${doctorInfo.specialization} Specialist`}
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Today&apos;s Appointments</p>
                  <p className="text-3xl font-bold">{todayAppointments?.length || 0}</p>
                </div>
                <div className="rounded-full bg-blue-100 w-12 h-12 flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Upcoming Appointments</p>
                  <p className="text-3xl font-bold">{upcomingCount || 0}</p>
                </div>
                <div className="rounded-full bg-cyan-100 w-12 h-12 flex items-center justify-center">
                  <Activity className="w-6 h-6 text-cyan-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Patients</p>
                  <p className="text-3xl font-bold">{patientsCount || 0}</p>
                </div>
                <div className="rounded-full bg-green-100 w-12 h-12 flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 gap-4 mb-8">
          <Link href="/doctor/appointments">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-blue-300">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4">
                  <div className="rounded-full bg-blue-100 w-12 h-12 flex items-center justify-center">
                    <Calendar className="w-6 h-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Manage Appointments</h3>
                    <p className="text-sm text-muted-foreground">View and update patient appointments</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>

          <Link href="/doctor/consultations">
            <Card className="hover:shadow-lg transition-shadow cursor-pointer border-2 hover:border-cyan-300">
              <CardContent className="pt-6">
                <div className="flex items-center gap-4">
                  <div className="rounded-full bg-cyan-100 w-12 h-12 flex items-center justify-center">
                    <Activity className="w-6 h-6 text-cyan-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">Consultations</h3>
                    <p className="text-sm text-muted-foreground">Manage online consultations</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        </div>

        {/* Today's Appointments */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Today&apos;s Schedule</CardTitle>
                <CardDescription>Appointments scheduled for today</CardDescription>
              </div>
              <Button asChild variant="outline">
                <Link href="/doctor/appointments">View All</Link>
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {todayAppointments && todayAppointments.length > 0 ? (
              <div className="space-y-4">
                {todayAppointments.map((appointment: any) => (
                  <div key={appointment.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <p className="font-semibold">{appointment.patient.profiles.full_name}</p>
                      <p className="text-sm text-muted-foreground">Time: {appointment.appointment_time}</p>
                      <p className="text-sm text-muted-foreground">Reason: {appointment.reason}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <span
                        className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                          appointment.status === "confirmed"
                            ? "bg-green-100 text-green-700"
                            : appointment.status === "scheduled"
                              ? "bg-blue-100 text-blue-700"
                              : "bg-gray-100 text-gray-700"
                        }`}
                      >
                        {appointment.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-muted-foreground">No appointments scheduled for today</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
