import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { ArrowLeft } from "lucide-react"

export default async function DoctorConsultationsPage() {
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get all consultations
  const { data: consultations } = await supabase
    .from("consultations")
    .select(
      `
      *,
      patient:patient_id (
        id,
        profiles!inner (full_name, email, phone)
      )
    `,
    )
    .eq("doctor_id", user.id)
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50">
      <header className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <Button asChild variant="ghost" size="sm" className="mb-2">
            <Link href="/doctor/dashboard">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
          <h1 className="text-2xl font-bold text-blue-900">Manage Consultations</h1>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <h2 className="text-xl font-semibold mb-6">Online Consultations</h2>

        {consultations && consultations.length > 0 ? (
          <div className="grid gap-4">
            {consultations.map((consultation: any) => (
              <Card key={consultation.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle>{consultation.patient.profiles.full_name}</CardTitle>
                      <CardDescription>
                        {new Date(consultation.created_at).toLocaleDateString("en-US", {
                          year: "numeric",
                          month: "long",
                          day: "numeric",
                        })}
                      </CardDescription>
                    </div>
                    <span
                      className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                        consultation.status === "completed"
                          ? "bg-green-100 text-green-700"
                          : consultation.status === "ongoing"
                            ? "bg-blue-100 text-blue-700"
                            : consultation.status === "pending"
                              ? "bg-yellow-100 text-yellow-700"
                              : "bg-red-100 text-red-700"
                      }`}
                    >
                      {consultation.status}
                    </span>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm font-medium">Patient Contact</p>
                        <p className="text-sm text-muted-foreground">{consultation.patient.profiles.email}</p>
                        {consultation.patient.profiles.phone && (
                          <p className="text-sm text-muted-foreground">{consultation.patient.profiles.phone}</p>
                        )}
                      </div>
                      <div>
                        <p className="text-sm font-medium">Consultation Type</p>
                        <p className="text-sm text-muted-foreground capitalize">{consultation.consultation_type}</p>
                      </div>
                    </div>
                    {consultation.diagnosis && (
                      <div>
                        <p className="text-sm font-medium">Diagnosis</p>
                        <p className="text-sm text-muted-foreground">{consultation.diagnosis}</p>
                      </div>
                    )}
                    {consultation.prescription && (
                      <div>
                        <p className="text-sm font-medium">Prescription</p>
                        <p className="text-sm text-muted-foreground">{consultation.prescription}</p>
                      </div>
                    )}
                    {consultation.notes && (
                      <div>
                        <p className="text-sm font-medium">Notes</p>
                        <p className="text-sm text-muted-foreground">{consultation.notes}</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <Card>
            <CardContent className="text-center py-12">
              <p className="text-muted-foreground">No consultations yet</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
