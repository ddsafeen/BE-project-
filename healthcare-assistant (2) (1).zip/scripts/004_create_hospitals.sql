-- Create hospitals table for location mapping
create table if not exists public.hospitals (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  address text not null,
  city text not null,
  state text not null,
  zip_code text,
  phone text,
  email text,
  latitude decimal(10, 8),
  longitude decimal(11, 8),
  services text[],
  emergency_available boolean default true,
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.hospitals enable row level security;

-- RLS Policies for hospitals - public read access
create policy "hospitals_select_all"
  on public.hospitals for select
  to authenticated
  using (true);

-- Only admins can insert/update/delete hospitals
create policy "hospitals_admin_all"
  on public.hospitals for all
  using (
    exists (
      select 1 from public.profiles
      where profiles.id = auth.uid()
      and profiles.role = 'admin'
    )
  );
