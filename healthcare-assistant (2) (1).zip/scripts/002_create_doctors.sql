-- Create doctors table with specialization and availability
create table if not exists public.doctors (
  id uuid primary key references public.profiles(id) on delete cascade,
  specialization text not null,
  qualification text,
  experience_years integer,
  consultation_fee decimal(10, 2),
  bio text,
  available boolean default true,
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.doctors enable row level security;

-- RLS Policies for doctors
create policy "doctors_select_all"
  on public.doctors for select
  to authenticated
  using (true);

create policy "doctors_insert_own"
  on public.doctors for insert
  with check (auth.uid() = id);

create policy "doctors_update_own"
  on public.doctors for update
  using (auth.uid() = id);
