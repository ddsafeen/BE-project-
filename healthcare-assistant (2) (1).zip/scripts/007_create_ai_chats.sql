-- Create AI chat sessions table
create table if not exists public.ai_chat_sessions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text default 'New Consultation',
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.ai_chat_sessions enable row level security;

-- RLS Policies for AI chat sessions
create policy "ai_chat_sessions_select_own"
  on public.ai_chat_sessions for select
  using (auth.uid() = user_id);

create policy "ai_chat_sessions_insert_own"
  on public.ai_chat_sessions for insert
  with check (auth.uid() = user_id);

create policy "ai_chat_sessions_update_own"
  on public.ai_chat_sessions for update
  using (auth.uid() = user_id);

create policy "ai_chat_sessions_delete_own"
  on public.ai_chat_sessions for delete
  using (auth.uid() = user_id);

-- Create AI chat messages table
create table if not exists public.ai_chat_messages (
  id uuid primary key default gen_random_uuid(),
  session_id uuid not null references public.ai_chat_sessions(id) on delete cascade,
  role text not null check (role in ('user', 'assistant')),
  content text not null,
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.ai_chat_messages enable row level security;

-- RLS Policies for AI chat messages
create policy "ai_chat_messages_select_own"
  on public.ai_chat_messages for select
  using (
    exists (
      select 1 from public.ai_chat_sessions
      where ai_chat_sessions.id = ai_chat_messages.session_id
      and ai_chat_sessions.user_id = auth.uid()
    )
  );

create policy "ai_chat_messages_insert_own"
  on public.ai_chat_messages for insert
  with check (
    exists (
      select 1 from public.ai_chat_sessions
      where ai_chat_sessions.id = ai_chat_messages.session_id
      and ai_chat_sessions.user_id = auth.uid()
    )
  );
