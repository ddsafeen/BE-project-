-- Seed some sample hospitals
insert into public.hospitals (name, address, city, state, zip_code, phone, latitude, longitude, services, emergency_available)
values
  ('City General Hospital', '123 Main Street', 'New York', 'NY', '10001', '(212) 555-0100', 40.7580, -73.9855, ARRAY['Emergency', 'Surgery', 'Cardiology', 'Pediatrics'], true),
  ('St. Mary Medical Center', '456 Oak Avenue', 'Los Angeles', 'CA', '90001', '(213) 555-0200', 34.0522, -118.2437, ARRAY['Emergency', 'Orthopedics', 'Neurology', 'Oncology'], true),
  ('Memorial Hospital', '789 Pine Road', 'Chicago', 'IL', '60601', '(312) 555-0300', 41.8781, -87.6298, ARRAY['Emergency', 'Maternity', 'ICU', 'Radiology'], true),
  ('Riverside Health Clinic', '321 River Drive', 'Houston', 'TX', '77001', '(713) 555-0400', 29.7604, -95.3698, ARRAY['General Practice', 'Pediatrics', 'Dermatology'], false),
  ('Mountain View Hospital', '654 Hill Street', 'Phoenix', 'AZ', '85001', '(602) 555-0500', 33.4484, -112.0740, ARRAY['Emergency', 'Trauma Center', 'Burn Unit'], true)
on conflict do nothing;
