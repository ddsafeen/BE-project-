-- Create patients table with medical information
create table if not exists public.patients (
  id uuid primary key references public.profiles(id) on delete cascade,
  date_of_birth date,
  gender text check (gender in ('male', 'female', 'other')),
  blood_group text,
  allergies text,
  medical_history text,
  emergency_contact text,
  emergency_phone text,
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.patients enable row level security;

-- RLS Policies for patients
create policy "patients_select_own"
  on public.patients for select
  using (auth.uid() = id);

create policy "patients_insert_own"
  on public.patients for insert
  with check (auth.uid() = id);

create policy "patients_update_own"
  on public.patients for update
  using (auth.uid() = id);

-- Allow doctors to view patient info for their appointments
create policy "patients_select_by_doctor"
  on public.patients for select
  using (
    exists (
      select 1 from public.appointments
      where appointments.patient_id = patients.id
      and appointments.doctor_id = auth.uid()
    )
  );
