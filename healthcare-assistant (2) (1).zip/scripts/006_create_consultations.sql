-- Create consultations table for online consultations
create table if not exists public.consultations (
  id uuid primary key default gen_random_uuid(),
  appointment_id uuid references public.appointments(id) on delete cascade,
  patient_id uuid not null references public.profiles(id) on delete cascade,
  doctor_id uuid not null references public.profiles(id) on delete cascade,
  consultation_type text not null check (consultation_type in ('video', 'audio', 'chat')),
  status text not null default 'pending' check (status in ('pending', 'ongoing', 'completed', 'cancelled')),
  start_time timestamp with time zone,
  end_time timestamp with time zone,
  diagnosis text,
  prescription text,
  notes text,
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.consultations enable row level security;

-- RLS Policies for consultations
create policy "consultations_select_own"
  on public.consultations for select
  using (auth.uid() = patient_id or auth.uid() = doctor_id);

create policy "consultations_insert_doctor"
  on public.consultations for insert
  with check (auth.uid() = doctor_id or auth.uid() = patient_id);

create policy "consultations_update_own"
  on public.consultations for update
  using (auth.uid() = patient_id or auth.uid() = doctor_id);
